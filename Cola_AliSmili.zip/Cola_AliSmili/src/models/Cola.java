package models;

public interface Cola<T> {
	  void push(T ele);
	  T pop();

}
